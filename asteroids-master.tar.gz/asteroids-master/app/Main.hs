module Main where

import Asteroids

main :: IO ()
main = run
